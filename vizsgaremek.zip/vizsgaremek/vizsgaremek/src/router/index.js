import {createRouter, createWebHistory} from 'vue-router'
import HomeView from "@/views/HomeView.vue";
import DogsView from "@/views/DogsView.vue";
import CatsView from "@/views/CatsView.vue";
import AdoptionView from "@/views/AdoptionView.vue";
import TemporaryView from "@/views/TemporaryView.vue";
import EventsView from "@/views/EventsView.vue";
import UserView from "@/views/UserView.vue";

const router = createRouter({
    history: createWebHistory(import.meta.env.BASE_URL),
    routes: [
        {
            path: '/',
            name: 'home',
            component: HomeView,
            meta: {
                title: 'Kezdőlap',
            }
        },
        {
            path: '/dogs',
            name: 'dogs',
            component: DogsView,
            meta: {
                title: 'Kutyák',
            }
        },
        {
            path: '/cats',
            name: 'cats',
            component: CatsView,
            meta: {
                title: 'Macskák'
            }
        },
        {
            path: '/adoption',
            name: 'adoption',
            component: AdoptionView,
            meta: {
                title: 'Örökbefogadás'
            }
        },
        {
            path: '/temporary',
            name: 'temporary',
            component: TemporaryView,
            meta: {
                title: 'Ideiglenes gazdi',
            }
        },
        {
            path: '/events',
            name: 'events',
            component: EventsView,
            meta: {
                title: 'Események',
            }
        },
        {
            path: '/user',
            name: 'user',
            component: UserView,
            meta: {
                title: 'Bejelentkezés',
            }
        }
    ],
})

export default router