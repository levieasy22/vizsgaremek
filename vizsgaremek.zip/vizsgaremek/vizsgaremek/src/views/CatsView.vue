<script>
export default {
  name: "CatsView.vue"
}
</script>

<template>

</template>

<style scoped>

</style>