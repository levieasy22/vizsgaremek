<script>
export default {
  name: "EventsView.vue"
}
</script>

<template>

</template>

<style scoped>

</style>