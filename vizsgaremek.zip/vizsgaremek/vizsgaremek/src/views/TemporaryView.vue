<script>
export default {
  name: "TemporaryView.vue"
}
</script>

<template>

</template>

<style scoped>

</style>