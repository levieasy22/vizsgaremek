<script>
export default {
  name: "UserView.vue"
}
</script>

<template>

</template>

<style scoped>

</style>