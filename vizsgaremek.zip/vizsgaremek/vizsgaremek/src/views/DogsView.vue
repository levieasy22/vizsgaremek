<script>
export default {
  name: "DogsView.vue"
}
</script>

<template>

</template>

<style scoped>

</style>