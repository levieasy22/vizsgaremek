<script>
export default {
  name: "HomeView.vue"
}
</script>

<template>

</template>

<style scoped>

</style>